<?php
	ini_set('display_errors', 1);
	// print("BIBA");
	require_once 'application/bootstrap.php';
?>