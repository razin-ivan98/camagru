	<script src="login.js"></script>
	<div class="border">
		<div class="form">
			<div class="title">
				<h2>LOGIN</h2>
			</div>
				
				<form id="login_form">
					<div class="str"><text>LOGIN</text><input type="text" name="login"/></div>
					<div class="str"><text>PASSWORD</text><input type="password" name="password"/></div>
					<div class="str"><button class="button" type="button" onclick="log_in();">Submit</button></div>
				</form>
				<div class="str"></div>
				<div class="str"><a href="/create_account">Create Account</a></div>
			
		</div>
	</div>