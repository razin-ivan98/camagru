<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="UTF-8">
		<title>PicChat</title>
		<link rel="stylesheet" href="login.css">
	</head>
	<body>
		<div class="header">
		<div class="logo"> 
			<a href="/feeds">
				<img class="logo-image", src="logolong.png">
			</a>
		</div>
		</div>
		<div class="marg"></div>
		<div class="page">
			<?php include 'application/views/'.$content_view;?>
		</div>
		<div class="footer">
		
		</div>
	</body>
</html>