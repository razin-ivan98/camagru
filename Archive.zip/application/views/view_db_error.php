<script src="login.js"></script>
	<div class="border">
		<div class="form">
			<div class="title">
				<h2>DATABASE_ERROR</h2>
			</div>

				<div class="str"></div>
				<div class="str"><a href="/feeds">Main Page</a></div>
			
		</div>
	</div>