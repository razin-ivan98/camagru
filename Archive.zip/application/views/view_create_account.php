	<script src="create_account.js"></script>
	<div class="border">
		<div class="form">
			<div class="title">
				<h2>CREATE ACCOUNT</h2>
			</div>
				
				<form id="create_account_form">
					<div class="str"><text>LOGIN</text><input type="text" name="login"/></div>
					<div class="str"><text>PASSWORD</text><input type="password" name="password"/></div>
					<div class="str"><button class="button" type="button" onclick="create_account();">Submit</button></div>
				</form>

				<div class="str"><a href="/login">Login</a></div>
			
		</div>
	</div>